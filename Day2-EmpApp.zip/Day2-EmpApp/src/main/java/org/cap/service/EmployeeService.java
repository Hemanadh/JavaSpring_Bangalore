package org.cap.service;

import java.util.List;

import org.cap.pojo.Employee;

public interface EmployeeService {
	
	public void insertEmployee(Employee employee);
	public List<Employee> getAllEmployees();

}

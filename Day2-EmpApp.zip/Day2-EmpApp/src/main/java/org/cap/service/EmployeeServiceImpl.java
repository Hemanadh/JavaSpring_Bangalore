package org.cap.service;

import java.util.List;

import org.cap.dao.EmployeeDao;
import org.cap.dao.EmployeeDaoImpl;
import org.cap.pojo.Employee;

public class EmployeeServiceImpl implements EmployeeService{

	private EmployeeDao empDao=new EmployeeDaoImpl();
	
	@Override
	public void insertEmployee(Employee employee) {
		//Write your business Logic
		empDao.insertEmployee(employee);
	}

	@Override
	public List<Employee> getAllEmployees() {
		
		return empDao.getAllEmployees();
	}

}

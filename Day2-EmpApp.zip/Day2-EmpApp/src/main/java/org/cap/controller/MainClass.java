package org.cap.controller;

import java.util.List;
import java.util.Scanner;

import org.cap.pojo.Employee;
import org.cap.service.EmployeeService;
import org.cap.service.EmployeeServiceImpl;
import org.cap.view.EmployeeUI;

public class MainClass {

	public static void main(String[] args) {
	
		EmployeeUI ui=new EmployeeUI();
		EmployeeService employeeService=new EmployeeServiceImpl();
		String userchoice=null;
		Scanner sc=new Scanner(System.in);
		
		do{
			
			
			int choice=ui.menuDetails();
			switch(choice)
			{
				case 1:
					Employee employee= ui.getEmployeeDetails();
					employeeService.insertEmployee(employee);
					break;
					
				case 4:
					List<Employee> employees=employeeService.getAllEmployees();
					ui.printAllEmployees(employees);
					break;
					
				case 6:
					System.exit(0);
			}
			System.out.println("Do you wish to continue?[y|n]");
			userchoice=sc.next();
		}while(userchoice.charAt(0)=='Y'||userchoice.charAt(0)=='y');
		
	}
	
	
	

}

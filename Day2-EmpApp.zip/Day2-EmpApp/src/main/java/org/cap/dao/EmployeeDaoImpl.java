package org.cap.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import org.cap.pojo.Employee;

public class EmployeeDaoImpl implements EmployeeDao{

	private HashMap<Integer, Employee> empRepo=new HashMap<>();
	
	@Override
	public void insertEmployee(Employee employee) {
		empRepo.put(employee.getEmpId(), employee);
	}

	@Override
	public List<Employee> getAllEmployees() {
		Collection<Employee> employees=  empRepo.values();
		List<Employee> employees2=new ArrayList<>();
		for(Employee employee:employees){
			employees2.add(employee);
		}
		
		return employees2;
	}

}

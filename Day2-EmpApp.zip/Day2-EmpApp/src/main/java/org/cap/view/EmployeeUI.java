package org.cap.view;

import java.util.List;
import java.util.Scanner;

import org.cap.pojo.Employee;

public class EmployeeUI {
	
	public Employee getEmployeeDetails(){
		
		Employee emp=new Employee();
		Scanner sc=new Scanner(System.in);
		
		
		System.out.println("Enter Employee Id:");
		int employeeId=sc.nextInt();
		
		System.out.println("Enter Employee Name:");
		String employeeName=sc.next();
		
		System.out.println("Enter Employee Salary:");
		double employeeSalary=sc.nextDouble();
		
		emp.setEmpId(employeeId);
		emp.setEmpName(employeeName);
		emp.setSalary(employeeSalary);
		
		return emp;
	}
	
	public int menuDetails(){
		System.out.println("1.Insert Employee ");
		System.out.println("2.Update Employee ");
		System.out.println("3.Delete Employee ");
		System.out.println("4.ListAll Employee ");
		System.out.println("5.Find Employee ");
		System.out.println("6.Exit ");
		System.out.println("Enter your option[1-6]: ");
		
		Scanner sc=new Scanner(System.in);
		int choice=sc.nextInt();
		return choice;
	}
	
	
	
	public void printAllEmployees(List<Employee> employees){
		
		for(Employee employee:employees)
			System.out.println(employee);
		
	}
	
	

}
